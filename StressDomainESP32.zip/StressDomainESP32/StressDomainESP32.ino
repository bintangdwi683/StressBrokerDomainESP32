#include <WiFi.h>
#include <PubSubClient.h>
#include <WiFiClientSecure.h>
#include <time.h>

const char* ssid = "Hovsky";
const char* password = "passwordapa";

const char* mqtt_server = "mqtt.domainkamu.com";
const int mqtt_port = 8883;
const char* mqtt_topic = "esp32/bintang/status";

const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 25200;
const int daylightOffset_sec = 0;

unsigned long previousMillis = 0;
const unsigned long interval = 1000;

unsigned long previousReconnectMillis = 0;
const unsigned long reconnectInterval = 5000;

WiFiClientSecure espClient;
PubSubClient client(espClient);

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Menghubungkan ke ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("Wi-Fi terhubung");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
}

bool tryReconnect() {
  Serial.print("Mencoba koneksi MQTT SSL...");
  String clientId = "ESP32Client-";
  clientId += String(random(0xffff), HEX);
  
  if (client.connect(clientId.c_str())) {
    Serial.println("terhubung");
    return true;
  } else {
    Serial.print("gagal, rc=");
    Serial.println(client.state());
    return false;
  }
}

void kirimDataMQTT() {
  struct tm timeinfo;
  if (getLocalTime(&timeinfo)) {
    char dateStr[11];
    char timeStr[9];
    strftime(dateStr, sizeof(dateStr), "%Y-%m-%d", &timeinfo);
    strftime(timeStr, sizeof(timeStr), "%H:%M:%S", &timeinfo);

    String macAddr = WiFi.macAddress();
    int randVal = esp_random() % 2;
    const char* statusStr = (randVal == 1) ? "On" : "Off";

    char payload[200];
    snprintf(payload, sizeof(payload), 
             "{\"id\":\"%s\",\"Date\":\"%s\",\"time\":\"%s\",\"Status\":\"%s\"}", 
             macAddr.c_str(), dateStr, timeStr, statusStr);

    client.publish(mqtt_topic, payload);
    Serial.println(payload);
  } else {
    Serial.println("Gagal mengambil waktu NTP");
  }
}

void setup() {
  Serial.begin(115200);
  
  setup_wifi();
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  
  espClient.setInsecure();
  client.setServer(mqtt_server, mqtt_port);
  randomSeed(esp_random());
}

void loop() {
  if (!client.connected()) {
    unsigned long currentReconnectMillis = millis();
    if (currentReconnectMillis - previousReconnectMillis >= reconnectInterval) {
      previousReconnectMillis = currentReconnectMillis;
      
      if (tryReconnect()) {
        previousMillis = millis();
      }
    }
  } else {
    client.loop();
  }

  if (client.connected()) {
    unsigned long currentMillis = millis();
    if (currentMillis - previousMillis >= interval) {
      previousMillis = currentMillis;
      kirimDataMQTT();
    }
  }
}